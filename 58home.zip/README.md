## 58Home 
use react router redux to finish the project
## 页面展示

地址 
![地址](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/141502f8017745c994971231ad675f2a~tplv-k3u1fbpfcp-zoom-1.image)
订单页
![订单页](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/06325bfd448c475691b3bb4b35056720~tplv-k3u1fbpfcp-zoom-1.image)
首页 
![首页](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0ceffdb4c3b84f98867dcbd73d98e5e9~tplv-k3u1fbpfcp-zoom-1.image)
我的 
![我的](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5ab40cca795340daa87d841e43f97a20~tplv-k3u1fbpfcp-zoom-1.image)
详情页 
![详情页](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a48c898db03f410482677addba2ed651~tplv-k3u1fbpfcp-zoom-1.image)