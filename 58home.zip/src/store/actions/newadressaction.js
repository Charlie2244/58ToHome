function addnewAdressInfo(data){
  return {
    type:'addAdress',
    data
  }
}
export {
  addnewAdressInfo
}