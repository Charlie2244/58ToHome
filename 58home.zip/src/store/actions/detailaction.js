function addDetailInfo(data) {
  return {
      type:"addDetail",
      data
  }
}

export {
  addDetailInfo
}