import * as historykeywords from './hkaction';
import * as newadress from './newadressaction';
import * as detail from './detailaction'
export default {
    hk:historykeywords,
    ad:newadress,
    detail:detail
}